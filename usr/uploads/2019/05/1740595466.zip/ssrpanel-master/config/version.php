<?php

return [
    'number' => '450',
    'name'   => 'Standard'
];